#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "$0")" && pwd)"
POC="$ROOT/old_genesis_tar_overflow_poc.c"
BIN="$ROOT/old_genesis_tar_overflow_poc"

echo "== Firedancer genesis TAR size integer overflow reproduction =="
echo

echo "[1/3] Vulnerable code pattern being modeled:"
echo 'FD_TEST( actual_decompressed_sz >= 512UL + fd_tar_meta_get_size( meta ) );'
echo

echo "[2/3] Building PoC with AddressSanitizer:"
if command -v clang >/dev/null 2>&1; then
  CC=clang
elif command -v cc >/dev/null 2>&1; then
  CC=cc
elif command -v gcc >/dev/null 2>&1; then
  CC=gcc
else
  echo "No C compiler found. Please install clang, cc, or gcc." >&2
  exit 1
fi

"$CC" -O0 -g -fsanitize=address,undefined "$POC" -o "$BIN"
echo "Compiler: $CC"
echo "Built:    $BIN"
echo

echo "[3/3] Running PoC."
echo "Expected result: integer wrap makes the vulnerable size check pass, then ASan reports an out-of-bounds read."
echo

"$BIN"
status=$?

echo
if [ "$status" -ne 0 ]; then
  echo "PoC process exited with status $status after AddressSanitizer detected the out-of-bounds read."
  echo "This crash is the expected vulnerable behavior for the reproduction."
  exit 0
fi

echo "PoC finished without an AddressSanitizer crash. Check whether AddressSanitizer is supported by the compiler/runtime."
