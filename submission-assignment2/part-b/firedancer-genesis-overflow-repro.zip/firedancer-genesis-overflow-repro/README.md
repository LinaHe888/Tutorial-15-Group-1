# Firedancer Genesis TAR Size Integer Overflow Reproduction

This folder contains a minimal reproduction for a Firedancer genesis TAR parsing bug.

## Vulnerability

The vulnerable old code pattern was:

```c
FD_TEST( actual_decompressed_sz >= 512UL + fd_tar_meta_get_size( meta ) );
```

The expression `512UL + fd_tar_meta_get_size(meta)` can overflow when the TAR size field is crafted as a very large `ulong`.

Example:

```text
blob_sz = ULONG_MAX = 18446744073709551615
512 + blob_sz wraps to 511
```

The bounds check can then pass incorrectly:

```text
actual_decompressed_sz = 528
528 >= 511 -> true
```

After that, the parser trusts the malformed TAR entry and reads beyond the decompressed buffer.

## Impact

Confirmed impact:

```text
Integer overflow
Bounds check bypass
Out-of-bounds read
Crash under AddressSanitizer
```

Practical security impact:

```text
Denial of service during genesis archive parsing / node initialization
```

This is not a normal live-network remote packet exploit. It requires the vulnerable Firedancer process to parse a malicious genesis archive.

## Requirements

macOS or Linux with one C compiler:

```text
clang
cc
gcc
```

AddressSanitizer support is required for the clearest crash report.

## Run

```bash
cd firedancer-genesis-overflow-repro
chmod +x ./run_repro.sh
./run_repro.sh
```

## Expected Output

Important lines:

```text
actual_decompressed_sz=528
blob_sz=18446744073709551615
vulnerable 512+blob_sz=511
vulnerable_check = actual_decompressed_sz >= 512+blob_sz -> 1
vulnerable code trusts the wrapped size and enters the blob read path
```

Then AddressSanitizer should report:

```text
ERROR: AddressSanitizer: stack-buffer-overflow
READ of size 1
Memory access ... overflows this variable
```

## Report Summary

This vulnerability is caused by unsigned integer overflow in a genesis TAR size check. A malicious TAR header can set the `genesis.bin` size to `ULONG_MAX`, causing `512UL + size` to wrap to a small value. The vulnerable bounds check passes incorrectly, and the parser continues into a read path even though the claimed blob is not present. The PoC demonstrates this with AddressSanitizer, which reports an out-of-bounds read.
